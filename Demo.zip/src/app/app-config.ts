export class BerryConfig {
  static isCollapse_menu: boolean = false;
  static fontFamily: string = 'Roboto'; // Roboto, poppins, inter
}
